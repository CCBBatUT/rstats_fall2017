library(tidyverse)
library(cowplot)

######## Simulations ########
set.seed(260132) # This ensures that everyone begins with the same sequence of numbers

##### Sampling from probability distributions #####

## Uniform distribution
runif(n = 100, min = 0, max = 1)
hist(runif(n = 100, min = 0, max = 1)) # Part of base R. This is very useful for a quick look at your samples.

## Poisson distribution
rpois(n = 100, lambda = 1.5) # The distribution for discrete, countable events
hist(rpois(n = 1000, lambda = 1.5))

## Normal distribution
norm = rnorm(n = 100, mean = 0, sd = 1) # Standard normal distribution - R default
hist(norm) 

## Generate multiple distributions at once
# The replicate function is very similar to lapply or the map function from
# the purrr package. It executes a function or expression a specified number of times.
# The difference is that the functions can be executed without being applied on an object.
# The equivalent function in purrr is the rerun(). This is yet to be optimized though and replicate is currently
# much faster.

replicate(100, rnorm(200, 0, 0.9)) # Run rnorm() 100 times to get 100 different samples with 200 values each

# Exercise: Compute the means for 
# 1000 normally distributed samples and create a histogram.
# How does this compare to the distribution of 100 samples or 10 samples?

norm_means = x

## Binomial distribution
binom = rbinom(n = 100, size = 10, prob = 0.5) # Flip a fair coin 10 times
hist(binom)

# Single trial - 1 or 0 (Bernoulli distribution)
rbinom(10, 1, 0.5)

## Exercise: What does the distribution of heads from 
# flipping a tails-biased coin 250 times look like? (use n = 1000, p = 0.1)

coins = x

  
  
# If the coin was fair, you would get heads around 125 times. Let's compare.
hist(rbinom(1000, 250, 0.5), add = T) 

## Functions to simulate data multiple times
# Draw a histogram of the means of n samples from a standard normal distribution

normhist = function(n) hist(replicate(n, mean(rnorm(100))))
normhist(4000)

## Exercise: Modify the function to plot n means from m binomial samples 
binomhist = x
  


##### Stochastic Models #####

## Simulating from a linear model
# Step1: Define the model- larger cows produce more milk than smaller cows
#        y = b0 + b1*x + error

# Step 2: Set the parameters
b0 = 10 # Intercept 
b1 = 3 # Slope - rate of increase in milk production as size increases
errsd = 5

# Step 3: Code the independent values
n = 200   # Sample size
x = runif(n, min = 0.5, max = 10) # Weight in tons

# Step 4: Run the model
y = b0 + b1*x + rnorm(1, sd = errsd)

# Visualize the output
plot(x, y)
abline(b0, b1) # The deterministic relationship based on our model

# How well does the simulated sample reflect the true model?
mod = lm(y~x)
summary(mod)
abline(mod, col = "red")

## Exercise: 
# Part 1: Change n and see how the model fit changes


# Part 2: What happens if you sample only 10 individuals when there is no
# relationship between size and milk production?


  
## Population dynamic models
# Type 2 functional response predation - Numbero of prey consumed
# Model: p = a/(1+ a*h*N)  
# Parameters:
a = 0.5
h = 0.05
n = 300

# Using a number of different initial conditions in one go - create a vector of initial prey population sizes
N = sample(1:100, n, replace = TRUE) # Useful function for sampling discrete values like integers or sampling from vectors

# Simulate:
predprob = a/(1+ a*h*N)
eaten = rbinom(n, prob = predprob, size = N) # Randomly choose a number of prey to be eaten

# Plot result
plot(N, eaten)
curve(a/(1+a*h*x)*x, add = TRUE) # Plot the deterministic equation

## Exercise: Write a model to visualize density dependent growth of a population


# Model the mortality function


## Let's put birth and death together and model the change of population size over time
tmax = 20 # Number of time steps to go forward
# Initial conditions
N0 = 
  
# Model function
ricker = function(parameters)
{
  # Return Nt+1 for a given Nt
}

N = numeric(tmax + 1) # Holds the population sizes
N[1] = N0

# Stepping the model
for(t in 1:tmax) 
{
  N[t+1] = N[t] + ricker()
}

# Plot population over time
plot(0:tmax, N)