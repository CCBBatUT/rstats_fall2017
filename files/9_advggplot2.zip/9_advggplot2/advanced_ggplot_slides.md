What can ggplot do
========================================================
author: Claire McWhite
date: 11/10/17
autosize: true

Basic ggplot will make a plot
========================================================

- Custom changes to plots
- Controlling plot behavior
- Additional plot types
- Using outside images
- Composing figures


*The ChickWeight dataset*
========================================================

```r
library(tibble)
data("ChickWeight")
#dataset loads as matrix, but I'd like it be a tidyverse tibble
ChickWeight <- as_tibble(ChickWeight) 
print(head(ChickWeight))
```

```
# A tibble: 6 x 4
  weight  Time Chick   Diet
   <dbl> <dbl> <ord> <fctr>
1     42     0     1      1
2     51     2     1      1
3     59     4     1      1
4     64     6     1      1
5     76     8     1      1
6     93    10     1      1
```

Starting plot
========================================================

```r
library(ggplot2)
base_plot <- ggplot(data=ChickWeight, aes(x=Time, y=weight, group=Chick, color=Diet)) +
     geom_line() + 
     facet_wrap(~Diet, nrow=1)
```

Starting plot
========================================================

```r
plot(base_plot)
```

![plot of chunk unnamed-chunk-2](advanced_ggplot_slides-figure/unnamed-chunk-2-1.png)

Quick improvements
========================================================
- Load color palette to override non-colorblind accessible pastel defaults
- Load cowplot plot theme

```r
#custom palette
palette <- c("#0072B2","#E69F00","#009E24","#FF0000", "#979797","#5530AA")
library(cowplot)
cowplot_plot <- pmain <- ggplot(data=ChickWeight, aes(x=Time, y=weight, group=Chick, color=Diet)) +
     geom_line() + 
     #facet_wrap(~Diet, nrow=1) +
     scale_color_manual(values=palette)
```

Plotting with images
========================================================

```r
chick_concept <- ggplot(data.frame(Time=1:2,Weight=1:2), aes(Time, Weight)) +
   draw_image("images/chick_pic.png", scale = 0.2, x = - 0.3, y = -0.3) +
    draw_image("images/chick_pic.png",scale = 0.5, x = 0.2, y = 0.3) +
    geom_abline(slope = 1)
```

Plotting with images
========================================================

```r
plot(chick_concept)
```

![plot of chunk unnamed-chunk-4](advanced_ggplot_slides-figure/unnamed-chunk-4-1.png)


Line labels
========================================================

















```
Error in ChickWeight %>% filter(Diet == 1) : 
  could not find function "%>%"
```
