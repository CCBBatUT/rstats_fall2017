What can ggplot do
========================================================
author: Claire McWhite
date: 11/10/17
#autosize: true
width: 1440
height: 900

Subjects
========================================================

- Custom changes to plots
- Using outside images
- Controlling plot behavior
- Additional plot types
- Composing figures


*The ChickWeight dataset*
========================================================

```r
library(tibble)
data("ChickWeight")
#dataset loads as matrix, but I'd like it be a tidyverse tibble
ChickWeight <- as_tibble(ChickWeight) 
print(head(ChickWeight))
```

```
# A tibble: 6 x 4
  weight  Time Chick   Diet
   <dbl> <dbl> <ord> <fctr>
1     42     0     1      1
2     51     2     1      1
3     59     4     1      1
4     64     6     1      1
5     76     8     1      1
6     93    10     1      1
```

Basic plot
========================================================

```r
library(ggplot2)
pmain <- ggplot(data=ChickWeight, aes(x=Time, y=weight, group=Chick, color=Diet)) +
     geom_line() + 
     facet_wrap(~Diet, nrow=1)
```
***

```r
plot(pmain)
```

![plot of chunk unnamed-chunk-2](advanced_ggplot_slides-figure/unnamed-chunk-2-1.png)

Quick improvements
========================================================
- Load color palette to override non-colorblind accessible pastel defaults
- Load cowplot plot theme

```r
#custom palette
palette <- c("#0072B2","#E69F00","#009E24","#FF0000", "#979797","#5530AA")
library(cowplot)
pmain <- ggplot(data=ChickWeight, aes(x=Time, y=weight, group=Chick, color=Diet)) +
     geom_line() + 
     facet_wrap(~Diet, nrow=1) +
     scale_color_manual(values=palette)
```
***

```r
plot(pmain)
```

![plot of chunk unnamed-chunk-3](advanced_ggplot_slides-figure/unnamed-chunk-3-1.png)


Plotting with images
========================================================
left: 70%

```r
chick_concept <- ggplot(data.frame(Time=1:2,Weight=1:2), aes(Time, Weight)) +
   draw_image("images/chick_pic.png", scale = 0.2, x = - 0.3, y = -0.3) +
    draw_image("images/chick_pic.png",scale = 0.5, x = 0.2, y = 0.3) +
    geom_abline(slope = 1)
```
***

```r
plot(chick_concept)
```

![plot of chunk unnamed-chunk-5](advanced_ggplot_slides-figure/unnamed-chunk-5-1.png)


Line labels
========================================================
left: 70%

```r
library(dplyr)
#library(ggrepel)
ChickWeight_filt <- ChickWeight %>% filter(Diet == 1)

pmain <- ggplot(data=ChickWeight_filt, aes(x=Time, y=weight, group=Chick)) +
     geom_line() +
     scale_color_manual(values=palette)

xlabels <- axis_canvas(pmain, axis = "y") + 
    geom_text(data = filter(ChickWeight_filt, Time == max(Time)), 
                    aes(y = weight, label = Chick), x = 0, color="blue") 

pmain_labeled <- insert_yaxis_grob(pmain, xlabels, grid::unit(.25, "null"))
```
***

```r
ggdraw(pmain_labeled)
```

![plot of chunk unnamed-chunk-7](advanced_ggplot_slides-figure/unnamed-chunk-7-1.png)


Marginal densities
========================================================
left: 70%

```r
xpoint <- axis_canvas(pmain, axis = "x") + 
    geom_point(data=ChickWeight, aes(x=Time, y = weight, color=Diet), alpha = 0.7) + scale_color_manual(values=palette)

ydens <- axis_canvas(pmain, axis = "y", coord_flip = TRUE) + 
    geom_density(data=ChickWeight, aes(x=weight, fill=Diet), alpha = 0.7) +
     scale_fill_manual(values=palette)+
    coord_flip()

#Add axis plots to main plot
p1 <- insert_xaxis_grob(pmain, xpoint, grid::unit(.2, "null"), position = "top")
p1 <- insert_yaxis_grob(p1, ydens, grid::unit(.2, "null"), position = "right")
```
***

```r
ggdraw(p1)
```

![plot of chunk unnamed-chunk-9](advanced_ggplot_slides-figure/unnamed-chunk-9-1.png)


One level deeper into ggplot - Grobs (Graphical Objects)
========================================================

```r
pgrob <- ggplotGrob(pmain)

    print(pgrob)
```

```
TableGrob (10 x 7) "layout": 17 grobs
    z         cells       name                                    grob
1   0 ( 1-10, 1- 7) background zeroGrob[plot.background..zeroGrob.688]
2   5 ( 5- 5, 3- 3)     spacer                          zeroGrob[NULL]
3   7 ( 6- 6, 3- 3)     axis-l     absoluteGrob[GRID.absoluteGrob.684]
4   3 ( 7- 7, 3- 3)     spacer                          zeroGrob[NULL]
5   6 ( 5- 5, 4- 4)     axis-t                          zeroGrob[NULL]
6   1 ( 6- 6, 4- 4)      panel                gTree[panel-1.gTree.662]
7   9 ( 7- 7, 4- 4)     axis-b     absoluteGrob[GRID.absoluteGrob.676]
8   4 ( 5- 5, 5- 5)     spacer                          zeroGrob[NULL]
9   8 ( 6- 6, 5- 5)     axis-r                          zeroGrob[NULL]
10  2 ( 7- 7, 5- 5)     spacer                          zeroGrob[NULL]
11 10 ( 4- 4, 4- 4)     xlab-t                          zeroGrob[NULL]
12 11 ( 8- 8, 4- 4)     xlab-b  titleGrob[axis.title.x..titleGrob.665]
13 12 ( 6- 6, 2- 2)     ylab-l  titleGrob[axis.title.y..titleGrob.668]
14 13 ( 6- 6, 6- 6)     ylab-r                          zeroGrob[NULL]
15 14 ( 3- 3, 4- 4)   subtitle   zeroGrob[plot.subtitle..zeroGrob.686]
16 15 ( 2- 2, 4- 4)      title      zeroGrob[plot.title..zeroGrob.685]
17 16 ( 9- 9, 4- 4)    caption    zeroGrob[plot.caption..zeroGrob.687]
```

One level deeper into ggplot - Grobs (Graphical Objects)
========================================================


```r
    #Get rid of plot objects I don't want
    pgrob_removed <- gtable_remove_grobs(pgrob, c('ylab-r', 'axis-r', 'spacer', 'axis-b'))
    #Compact empty rows and columns
    pgrob_squashed <- gtable_squash_cols(pgrob_removed, c(7,8,9))
    pgrob_squashed <- gtable_squash_rows(pgrob_squashed, c(7))
    
    #Check that dimensions were squashed
    pgrob_squashed$widths
```

```
[1] 7pt                    1grobwidth             sum(1grobwidth, 3.5pt)
[4] 1null                  0cm                    0cm                   
[7] 0in                    0in                    0in                   
```

```r
    pgrob_squashed$heights
```

```
 [1] 7pt         0cm         0cm         0cm         0cm        
 [6] 1null       0in         1grobheight 0cm         7pt        
```

One level deeper into ggplot - Grobs (Graphical Objects)
========================================================

```r
pmod <- plot_grid(pgrob_squashed)
plot(pmod)
```

![plot of chunk unnamed-chunk-12](advanced_ggplot_slides-figure/unnamed-chunk-12-1.png)

Another view of a ggplot
========================================================

```r
pmain$data
```

```
# A tibble: 220 x 4
   weight  Time Chick   Diet
    <dbl> <dbl> <ord> <fctr>
 1     42     0     1      1
 2     51     2     1      1
 3     59     4     1      1
 4     64     6     1      1
 5     76     8     1      1
 6     93    10     1      1
 7    106    12     1      1
 8    125    14     1      1
 9    149    16     1      1
10    171    18     1      1
# ... with 210 more rows
```
***

```r
pmain$mapping
```

```
* x     -> Time
* y     -> weight
* group -> Chick
```
***

```r
pmain$labels
```

```
$x
[1] "Time"

$y
[1] "weight"

$group
[1] "Chick"
```

Using nonstandard geoms
========================================================
left: 70%

```r
library(ggridges)
library(dplyr)
ggridge_plot <- ChickWeight %>%  filter(Diet == 1) %>%
     ggplot(data=., aes(x=weight, y=Chick, group=Chick, fill=Diet)) +
     geom_density_ridges(alpha= 0.8) +
     scale_fill_manual(values=palette)
```
***

```r
plot(ggridge_plot) 
```

![plot of chunk unnamed-chunk-17](advanced_ggplot_slides-figure/unnamed-chunk-17-1.png)

Composing a figure
========================================================

```r
chickimg <- ggdraw() + draw_image("images/chick_pic.png")
top_row <- plot_grid(chickimg, chick_concept, labels = c("A", "B"), rel_widths = c(1,2)) 
                       
bottom_row <- plot_grid(ggridge_plot, pmain, p1, align = "hv", labels = c("C", "D", "E"), axis = "bt", nrow = 1)

chicken_fig <- plot_grid(top_row, bottom_row, nrow = 2)
```

Composing a figure
========================================================

```r
plot(chicken_fig)
```

![plot of chunk unnamed-chunk-19](advanced_ggplot_slides-figure/unnamed-chunk-19-1.png)

