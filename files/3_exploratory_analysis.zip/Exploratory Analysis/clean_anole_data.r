# EDA for anole data

# If you haven't installed tidyverse or cowplot, run:
# install.packages("tidyverse")
# install.packages("cowplot")
library(tidyverse)

# Part 1: Clean and check the data

anoles = read_csv("data/anoles.csv")
# Note: the single equal sign is another way of doing left assignment (<-)

# Take a look at the data
anoles
glimpse(anoles) # glimpse is helpful when you have a lot of columns

# This data 
  # Each row is a single observation,
  # Each column is a variable.
# This will be helpful for most of our analysis
  # However, sometimes it might be convienient to over-tidy the data.

# Let's put all of the variables other than ID, Site, and Color into a single column.

over_tidy_anoles = anoles %>% # The pipe operator ( %>% ) takes what's on the left and sends it to the first argument on the right.
  gather(key = "Variable", value = "Value", contains("("))
  # the gather function selected all of the columns that contained a "(" in their name
  # turned them into two new columsn: Variable (the former column names) and Value (their values)
  # You can find simlar functions by putting ?select_helpers into the console
# an alternative way to write this: 
  # over_tidy_anoles <- gather(anoles, key = "Variable", value = "Value", -`Anole ID`, -Site, -Color)

# What's the distribution of the data?
  # Here are a few ways to do this
over_tidy_anoles %>% ggplot(aes(x = Value)) +  # aes() connects columns in the data frame to graph features
  geom_histogram() + # Alternatively, you could try:
  # geom_density() + 
  # geom_freqpoly() +
  facet_wrap(~Variable, scales = "free") # A facet creates different sub-plots; 
                      # scales = "free" lets the different plots have different axis ranges

# A few things to note: 
  # Something is weird with Snout-Vent Length
  # We have 12 missing values (NA); these come from empty cells in the data file.

anoles %>% arrange(desc(`Snout-Vent Length (mm)`)) %>% glimpse # arrange(desc(...)) sorts in descending order

## Our problem lizard is apparently 80 meters long.
## You can either replace this with a missing value (NA) or check if there was a data entry error.
## For this hypothetical example, let's say we our data sheet said it was supposed to be 80.4

anoles = anoles %>% mutate(`Snout-Vent Length (mm)` = 
    if_else(`Snout-Vent Length (mm)` == 80469.2, 80.4, `Snout-Vent Length (mm)`))
  # The if_else function is used to mutate some of the values in a column

# These column names are irritatingly long.
anoles = anoles %>% rename(ID = `Anole ID`, SVL = `Snout-Vent Length (mm)`,
  Tail = `Tail Length (mm)`, Limb = `Limb Length (mm)`, Mass = `Mass (g)`,
  Height = `Perch Height (cm)`, Diameter = `Perch Diameter (cm)`)

# Let's examine SVL now that we've fixed the problem
anoles %>% ggplot(aes(x = SVL)) + geom_histogram()

##############
## Exercise: 
## Re-make over_tidy_anoles now that we've corrected the data
##############

# Let's make a table of basic summary statistics:
anole_summary = over_tidy_anoles %>% group_by(Variable) %>% 
  filter(!is.na(Value)) %>% 
  summarise(Mean = mean(Value), Standard_Deviation = sd(Value), Standard_Error = SD/sqrt(n()), 
    Median = median(Value), Min = min(Value), Max = max(Value),
    Lower_Quartile = quantile(Value, .25), Upper_Quartile = quantile(Value, .75))
# The missing values (NA) are a problem for some of these; fortunately, they are easy to ignore.

anole_summary

# We also have some data about each Site.  Let's read this in.
library(readxl) # This is installed with the tidyverse, but has to be loaded separately
excel_sheets("data/anole_sites.xlsx") # excel files can have more than one sheet
anole_sites = read_xlsx("data/anole_sites.xlsx", sheet = "anole_sites")

## The Precipitation and Temperature rows have text included with their values.  
## We can split these out with the separate() function in tidyr
anole_sites %>% separate(Temperature, c("Temperature", "deg_c"), sep = " ", convert = TRUE) 
# This splits the Temperature column at the space, and converts it into a number
# Alternate version:
anole_sites = anole_sites %>% separate(Temperature, c("Temperature", "deg_c"), sep = -4, convert = TRUE) %>% select(-deg_c)
# This separates he columns at 4 characters from the end, then discards the deg_c column.

##################
## Exercise:
## Separate Precipitation
################


# We'd like to combine this table with the individual anole data.  To do that, we need a join operation
anole_data = full_join(anoles, anole_sites, by = "Site") # there are a variety of join functions
anole_data # This adds new columns to anole corresponding to the site's temp., precip., lat., and long.

# Let's save our cleaned and joined data.
write_csv(anole_data, "data/clean_anole_data.csv")

