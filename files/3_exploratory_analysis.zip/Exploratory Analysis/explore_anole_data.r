# Now that the data has been cleaned, let's explore some plots
library(tidyverse)
library(cowplot)

# Do color morph frequencies vary by site?
anole_data %>% 
  ggplot(aes(x = Site, fill = Color)) + geom_bar(stat = "count") 


# Let's set some appropriate colors on the graph
anole_colors = (c("cornflowerblue","chocolate4","palegreen3")) # R has a lot of built-in colors; google "R color chart"
anole_data %>% 
  ggplot(aes(x = Site, fill = Color)) + geom_bar(stat = "count") + 
  scale_fill_manual(values = anole_colors) # fill refers to solid colors; color refers to points and lines

# Do any of the data vary by color?
over_tidy_anoles %>% 
  ggplot(aes(y = Value, x = Color, fill = Color)) + geom_boxplot() + 
  facet_wrap(~Variable, scales = "free") + 
  scale_fill_manual(values = anole_colors)

# What about by site?
over_tidy_anoles %>% 
  ggplot(aes(y = Value, x = Site)) + geom_boxplot() + 
  facet_wrap(~Variable, scales = "free")

# How does SVL vary by site?
anole_data %>% ggplot(aes(x = Site, y = SVL)) + 
  geom_boxplot()

# Is SVL associated with Tail Length?  
svl_tail_plot = anole_data %>% ggplot(aes(x = SVL, y = Tail)) + 
  geom_point() 
svl_tail_plot
# is SVL/Tail relationship structured by lizard color?
svl_tail_plot + aes(color = Color) + scale_color_manual(values = anole_colors)
# What about variation by site?
svl_tail_plot + aes(color = Color) + scale_color_manual(values = anole_colors) +
  facet_wrap(~Site)
# zoom in on each site
svl_tail_plot + aes(color = Color) + scale_color_manual(values = anole_colors) +
  facet_wrap(~Site, scales = "free")

# What about the average value at each site?
svl_tail_means = anole_data %>% group_by(Site) %>% 
    summarise(SVL = mean(SVL, na.rm = TRUE), Tail = mean(Tail, na.rm = TRUE)) %>% ungroup 
svl_tail_means %>% ggplot(aes(x = SVL, y = Tail)) + geom_point()

# is site temperature or precipitation involved?
svl_tail_means = svl_tail_means %>% bind_cols(anole_sites)
svl_tail_means %>% ggplot(aes(x = SVL, y = Tail)) + geom_point() + aes(color = Temperature)
svl_tail_means %>% ggplot(aes(x = SVL, y = Tail)) + geom_point() + aes(color = Precipitation)

###############
## Exercises:
##
## Generally, you expect to see larger lizards living higher in trees.  
## Is there a relationship between SVL, perch height, and perch diameter?  
## 
## Do they vary among colors and sites?
## 
## Is perch height or diameter more strongly associated with another variable?
## 
#########




## A more advanced way to look at SVL by site and precipitation

  # Combining raw data with descriptive statistics
anole_data %>% ggplot(aes(x = Site, y = SVL)) + 
  geom_violin(aes(color = Precipitation), fill = NA) +
  geom_jitter(shape = 21, width = .3, alpha = .5, color = "tomato")

# Let's re-order the x axis by increasing precipitation

precip_order = anole_data %>% 
  mutate(Site = reorder(Site, Precipitation))

svl_precip_plot = precip_order %>% ggplot(aes(x = Site, y = SVL)) + 
  geom_violin(aes(color = Precipitation), fill = NA) +
  geom_jitter(shape = 21, width = .3, alpha = .5, color = "tomato") +
  ylab("Snout-Vent Length (mm)")

# Let's add in the mean and standard error of SVL for each site.
svl_mean_se = precip_order %>% group_by(Site) %>% 
  filter(!is.na(SVL)) %>% 
  summarise(SE = sd(SVL)/sqrt(n()), SVL = mean(SVL)) %>% ungroup

svl_precip_plot = svl_precip_plot +
  geom_errorbar(aes(ymin = SVL - SE, ymax = SVL + SE), 
    data = svl_mean_se, color = grey(.5)) +
  geom_point(aes(y = SVL), data = svl_mean_se, size = 3, shape = 16)
svl_precip_plot

# Make a second plot for the precipitation at each site
precip_plot = precip_order %>% 
  ggplot(aes(x = Site, y = Precipitation, group = 1))+ 
  geom_line() + xlab("") + # removes the x label
  scale_x_discrete(position = "top") # This puts the x axis on top, which will make more sense in a moment

# Now we can combine them
final_plot = plot_grid(precip_plot, svl_precip_plot, # plot grid (part of cowplot) stacks two plots together
  ncol = 1, # Align the grids in a column
  rel_heights = c(1,3), # With the second plot 3x as large
  axis = "lr", align = "v") # vertically aligned along the left and right axes.

# Save the output as evidence you worked hard this week
ggsave("SVL_precip_plot.pdf", final_plot, width = 5, height = 4, scale = 2)

