library(tidyverse)
library(cowplot)
############ List Refresher #############
# lists are the most general data structure in R.
# They can contain anything (even other lists)

test_list = list(1:5, 
  its_a =list(c("bird", "plane", "superman"), status = c(FALSE, FALSE, TRUE)), 
  x~y+z, 
  mean_function = mean)
test_list

# lists elements can be accessed by their position or their names (if they have them)
test_list[[2]] # Note the double brackets
test_list$its_a

# This nests
test_list[[2]][[2]]
test_list$its_a$status
test_list$its_a[[2]]


########### Map Function ################
# Large problems in data analysis are often made of a bunch of small problems
  # Frequently, these smaller problems are similar and repetitive
  # Strategy:   
    # 1. Identify what varies among the repetitions
    # 2. Figure out how to do a single small problem
    # 3. Use a map() function to apply your solution to the small problem to all the variants

# Simple example:
# calculate the mean of each element in this list
x_list = list(a = 1:10, b = exp(-3:3), c = c(TRUE,FALSE,FALSE,TRUE))
x_list

# Brute-force method
list(
  mean(x_list[[1]]),
  mean(x_list[[2]]),
  mean(x_list[[3]])  )
# What if we had 500 objects in x_list?  
# It's clear that we want to use the function 'mean' on every element of x_list

map(x_list, mean)

# The map function: argument 1 is a vector or list; 
# argument 2 is the function to be applied to each element of the list

# median and quartiles for each list element
map(x_list, quantile, probs = 1:3/4) # probs is an argument passed to quantile that doesn't vary


########## Exercise: ##############
# There are 19 data files in data/sites
file_names = dir("data/sites", full.names=TRUE)

# use read_csv and map to read all of them in.
#Single use case: 
  read_csv(file_names[1])

site_dat = file_names %>% 


  
########### pmap: mapping with multiple variables)

# The pmap function takes a data frame or a list of variables 
  #  all elements of the list must have the same length; 
# It applies uses the list elements as function arguments
  # list elements with names are matched to the function argument with the same name
  # the rest are matched by position.

# Example: We want to generate some random numbers
# the function: runif(n, min, max) generates n random numbers between min and max
random_num_pars = data_frame(n = c(100, 25, 75, 50), min = c(-40, 0, 135, 15), max = min + c(100, 22, 68, 40))   
random_num_pars
random_nums = random_num_pars %>% pmap(runif)  
random_nums

random_nums %>% 
  flatten_dbl # this squashes the list into a numeric vector 

# You can apply a map function to the results of a map function

random_nums %>% 
  map(mean) %>% 
  flatten_dbl

# Or directly chain maps

random_nums %>% 
  map(quantile, probs = c(.025, .1, .25, .5, .75, .9, .975)) %>% # Fixed arguments to the function (like probs) can be added like this
  map(data_frame_) %>% #Note the _ after data_frame_; most tidyverse functions have an underscored version; these are easier to use with named vectors.  Generally, don't worry about these
  bind_rows %>% 
  bind_cols(random_num_pars) # This adds the original data frame in as new columns


############### Exercise ##########
# We want to add a column to our site data frame that lists the site name
site_names = LETTERS[1:19]

# Use pmap and the mutate command to add a "Site" column 
  # to each element of site_dat

all_sites = list() %>% 

######## Exercise ##################
library(broom)

# Part 2:
# Goal: look at the effects of the variables Limb, Mass, SVL, and Tail on Height in all_sites
# Build a series of linear regressions 
# The building block:

first_model = Height ~ SVL
lm(first_model, data = all_sites) %>% tidy

# If you couldn't get all_sites working, uncomment the following line
# all_sites = file_names %>% map(read_csv) %>% list(Site = site_names) %>% pmap(mutate) %>% bind_rows

## Create a list of regression looking at different combinations of effects,
  ## then tidy the moel coefficents (the tidy function), 

model_list = list( # the model formulas
)
regression_list = model_list %>% map(       ) %>% map(     )

# Part 2: 
  ## add a column to each element of that identifies the model
  ## merge into a single data frame
model_names = as.charater(model_list)

model_summary = 


############ User-Defined Functions ###################

# Goal: calculate the mean of the logarithm of the square root of the absolute value of 
  # each group of random numbers we generated earlier

# We could use a number of map functions:
random_nums %>% map(abs) %>% map(sqrt) %>% map(log) %>% map(mean)

# Or we could define a function that calculates mean(log(sqrt(abs(x))))
mean_log_sqrt_abs = function(x) {
  x %>% abs %>% sqrt %>% log %>% mean
}
random_nums %>% map(mean_log_sqrt_abs)

# Generally, write a function if you ever have to do something more than twice.

# Goal: take regression list from the last exercise,
  #  use the glance function to view model fit statistics

# The single-element version:     
  results = lm(model_list[[1]], data = all_sites) %>% # run model
    glance %>% # get summary statistics
    as_data_frame() # Convert them to a data frame
  results
  model_name = as.character(model_list[[1]]) # Convert the model formula to a character vector
  model_name # Unexpected behavior: fortunately, we only really care about the x variable 
  model_name = as.character(model_list[[1]])[3] # re-define
  results %>% mutate(model = model_name) # output
  
# Now turn this into a function  
lm_glance = function(formula, data = all_sites) { # arguments assigned default values
  results = lm(formula, data = data) %>% glance %>%  # the glance function shows model-wide summary stats
    as_data_frame()
  model_name = as.character(formula)[3]
  results %>% mutate(model = model_name) # The value of the last command in a function is returned
}
# map it together
map(model_list, lm_glance) %>% 
  bind_rows %>% # combine the rows
  arrange(AIC)  # Sort by AIC

######### Exercise ##########

# Estimate how the coefficients of the model (Height ~ SVL + Tail)
# change when a single observation is removed.
# Write a function to re-run the regression once with each individual removed, 
# tidy the coefficients
# Summarise your results with a histogram/density plot for each coeficient.
model_formula = Height~SVL+Tail

leave_one_out = function(which_one, data = all_sites, formula = model_formula) {
  # Fill in function
}

loo_results = map(     ) 

loo_results %>% ggplot(aes(x = estimate)) + geom_histogram(bins = 50) + facet_wrap(~term)